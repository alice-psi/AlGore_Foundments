contenidoEntrada = `
<section>
    <h2>Factorizacion</h2>
    <p>Pagina en desarrollo...</p>
    <h3>Vuelve mas tarde.</h3>
    <p>-</p>
</section>`;

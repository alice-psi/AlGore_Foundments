contenidoEntrada = `
<section>
    <h2>Ecuaciones de primer grado</h2>
    <p>Pagina en desarrollo...</p>
    <h3>Vuelve mas tarde.</h3>
    <p>-</p>
</section>`;
